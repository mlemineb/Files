

############################ APPLICATION SHINY ############################ 

#------------ SERVEUR ---------#
# create the server functions for the dashboard  





table_options <- function() {
  list(
    dom = 'Bfrtip',
    #Bfrtip
    pageLength = 10,
    buttons = list(
      list(extend = 'copy', title = "Copier"), 
      list(extend = 'excel', title = "Telecharger au format Excel"), 
      list(extend = 'print', title = "Imprimer")) ,
    searching = TRUE,
    editable = TRUE,
    scrollX=T,
    scrollY=T,
    columnDefs = list(list(visible=FALSE, targets=c(15))),
    fixedColumns = list(leftColumns = 2)
  )
}


library(shinyalert)
useShinyalert()


server <- shinyServer(function(input, output,session) { 
  

  
  #
  res_auth <- secure_server(
    check_credentials = check_credentials(credentials)
  )
  
  # Create reactive values including all credentials
  creds_reactive <- reactive({
    reactiveValuesToList(res_auth)
  })
  
  # Hide extraOutput only when condition is TRUE
  observe({
    if (!is.null(creds_reactive()$level) && creds_reactive()$level > 0) {shinyjs::hide("accordbyAgent") & shinyjs::hide("succesparAgent") & shinyjs::hide("StatNPC")  }
  })
  
  
  #output$auth_output <- renderPrint({
  #  reactiveValuesToList(res_auth)
  #})
  
  # Store JSON with logs in the temp dir
  track_usage(
    storage_mode = store_json(path = "//CPMUZD2BURVB.zres.ztech/MUP10HDP0_S/SMP10/webtracking_app/logs")
  )
  


  #creating the valueBoxOutput content
  output$value1 <- renderValueBox({
    valueBox(
      formatC(NB_simulation, format="d", big.mark=',')
      ,'NB de Leads:'
      ,icon = icon("stats",lib='glyphicon')
      ,color = "purple")
    
 })
  
  
  
  output$value2 <- renderValueBox({
    
    valueBox(
      formatC(Taux_de_traitement, format="d", big.mark=',')
      ,'Taux de traitement'
      ,icon = icon("hourglass",lib='glyphicon')
      ,color = "red")
    
  })
  
  
  
  
  output$value3 <- renderValueBox({
    
    valueBox(
      formatC(NB_contact_ab, format="d", big.mark=',')
      ,'NB de contact aboutis'
      ,icon = icon("earphone",lib='glyphicon')
      ,color = "blue")
    
  })
  
  
  output$value4 <- renderValueBox({
    
    valueBox(
      formatC(Taux_succes, format="d", big.mark=',')
      ,'Taux de succes:'
      ,icon = icon("ok",lib='glyphicon')
      ,color = "yellow")
    
  })
  
  
  output$value5 <- renderValueBox({
    
    valueBox(
      formatC(Montant_global, format="d", big.mark=',')
      ,'Montant accordés:'
      ,icon("euro",lib='glyphicon')
      ,color = "green")
    
  })
  
  
  output$value6 <- renderValueBox({
    
    valueBox(
      formatC(NBAccords, format="d", big.mark=',')
      ,"NB d'accords:"
      ,icon("ok-sign",lib='glyphicon')
      ,color = "teal")
    
  })
  
  #creating the plotOutput content
  
  
  output$accordbyAgent <- renderPlot({
    ggplot(data = STAT, 
           aes(x=NOM_AGT, y=CONSO_ACCORD, fill=factor(NOM_AGT))) + 
      geom_bar(position = "dodge", stat = "identity") + ylab("Nombre de dossier realisés") + 
      xlab("Agent") + theme(legend.position="bottom" 
                            ,plot.title = element_text(size=15, face="bold")) + 
      labs(fill = "agents")
  })
  
  
  output$succesparAgent <- renderPlot({
    ggplot(data = STAT, 
           aes(x=NOM_AGT, y=tx_succes, fill=factor(NOM_AGT))) + 
      geom_bar(position = "dodge", stat = "identity") + ylab("Taux de succés (en %)") + 
      xlab("Agent") + theme(legend.position="bottom" 
                            ,plot.title = element_text(size=15, face="bold")) + 
      labs(fill = "agents")
  })
  
  
  
  
  
  

  #output$contact_webtrack <- renderPlotly({
    
    #fig <- plot_ly(ts, x = ~factor(week), y = ~CONTACT, name = 'Simulations', type = 'scatter', mode = 'lines',
                   #line = list(color = 'orange', width = 4)) 
    #fig <- fig %>% add_trace(y = ~ACCORD, name = "Accords", line = list(color = 'rgb(22, 96, 167)', width = 4)) 
    #fig <- fig %>% layout(title = "",
    #                      xaxis = list(title = "Semaines"),
     #                     yaxis = list (title = "Nombre"))
                          
  #})
  
  output$contact_webtrack <- renderPlot({
    ggplot(data = ts, aes(x =  factor(week), y =NB_CONTACT ,group = 1)) +
      geom_line() +
      
      labs(title = "",
           x = "Semaines",
           y = "Nb de Simulations Web-tracking") +
      theme_bw() +
      theme(text=element_text(size = 16))
  })
  
    
  output$accord_webtrack <- renderPlot({
    ggplot(data = ts, aes(x =  factor(week), y =NB_ACCORD ,group = 1)) +
      geom_line() +
      
      labs(title = "",
           x = "Semaines",
           y = "Nb d'Accords Web-tracking") +
      theme_bw() +
      theme(text=element_text(size = 16))
  })
  
  

 
  

  

  
  output$StatNPC <- DT::renderDataTable(DT::datatable({
    data <- STAT
    if (input$man != "Tous") {
      data <- data[data$ID_AGT == input$man,]
    }
    if (input$trans != "Tous") {
      data <- data[data$NOM_AGT == input$trans,]
    }
    data
  },  selection = 'single', extensions = 'Buttons',
  options = list(
    dom = 'Bfrtip',
    #Bfrtip
    pageLength = 10,
    buttons = list(
      list(extend = 'copy', title = "Copier"), 
      list(extend = 'excel', title = "Telecharger au format Excel"), 
      list(extend = 'print', title = "Imprimer")) ,
    searching = TRUE,
    editable = TRUE,
    scrollX=T,
    scrollY=T,
    fixedColumns = list(leftColumns = 2)
  )))
  


  
  
  
  reader <- reactiveFileReader(intervalMillis = 1000, session, filePath = 
                                 "//CPMUZD2BURVB.zres.ztech/MUP10HDP0_S/SMP10/webtracking_app/Webtracking_file.xlsx", readFunc = read_excel)
  
  reader2 <- reactiveFileReader(intervalMillis = 1000, session, filePath = 
                                  "//CPMUZD2BURVB.zres.ztech/MUP10HDP0_S/SMP10/webtracking_app/traitement.csv", readFunc = data.table::fread,colClasses = 'character')
  
  
  
  ### interactive dataset 
  vals_trich<-reactive({
    data1 <-reader()
    data2 <-reader2()
    data1 <- dplyr::filter(data1,!data1$NU_COMPTE %in% data2$Num_compte )
    data3<-cbind.data.frame(data1,data.frame(Envoyer_sms=createLink(data1$NOMPART)),stringsAsFactors = FALSE)
    data3$Envoyer_sms<-as.character(data3$Envoyer_sms)
    data3$Envoyer_sms[data3$OPTIN_SMS==0]<-""
    data3$colr_flag <- ifelse(data3$CD_ORIENT_RISQ %in% c("R7","R6","R5") & data3$CD_ORIENT_APTNC=="A3" , 2, 
                              ifelse(data3$CD_ORIENT_RISQ %in% c("R7","R6","R5","R4") & data3$CD_ORIENT_APTNC=="A2", 1,
                                     0))
    colnames(data3)<- c("Num Compte","Nom","Produit","Date Simul","Nb de Simul","Montant","Duree","Age","Note Bal2","Score Risque","Score Appetence","Optin SMS","Envoyer sms"," Flag") 
    
    data3
  })
  
  
  # Generate reactive values
  rvs <- reactiveValues(
    data = NA
  )
  
  
  
  
  # Observe the source, update reactive values accordingly
  observeEvent(vals_trich(), {
    data<-vals_trich()
    rvs$data <- data
    
  })
  
  
  
  # sorted columns are colored now because CSS are attached to them
  output$mytable2 <- DT::renderDataTable({
    DT::datatable(reader2())
  })
  
  ### 1. create a datatable with checkboxes ###
  # taken from https://github.com/rstudio/DT/issues/93/#issuecomment-111001538
  # a) function to create inputs
  shinyInput <- function(FUN, ids, ...) {
    inputs <- NULL
    inputs <- sapply(ids, function(x) {
      inputs[x] <- as.character(FUN(inputId = x, label = NULL, ...))
    })
    inputs
  }
  # b) create dataframe with the checkboxes
  
  # c) create the datatable
  output$checkbox_table <- DT::renderDataTable({
    datatable(  { df <- data.frame(
      rvs$data ,
      Traiter = shinyInput(checkboxInput, rvs$data$Nom),
      stringsAsFactors = FALSE
    )
    }
    ,escape = FALSE, selection = 'single', extensions = 'Buttons',
    rownames = FALSE,
    options = list(
      autoWidth = FALSE,
      preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
      drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
      dom = 'Bfrtip',
      #Bfrtip
      pageLength = 10,
      buttons = list(
        list(extend = 'copy', title = "Copier"), 
        list(extend = 'excel', title = "Telecharger au format Excel"), 
        list(extend = 'print', title = "Imprimer")) ,
      searching = TRUE,
      scrollX=T,
      scrollY=T,
      columnDefs = list(list(visible=FALSE, targets=c(13))))) %>% formatStyle(
        'X.Flag', target = 'row', 
        backgroundColor = styleEqual(c(2, 1), c('green', 'lightgreen')))
  })
  
  ### 2. save rows when user hits submit -- either to new or existing csv ###
  observeEvent(input$submit, {
    # if user has not put in a username, don't add rows and show modal instead
    if(input$username == "") {
      showModal(modalDialog(
        "Please enter your username first", 
        easyClose = TRUE,
        footer = NULL,
        class = "error"
      ))
    } else {
      responses <- data.frame(user = input$username,
                              Num_compte = rvs$data$`Num Compte`,
                              Traitement = sapply(rvs$data$Nom, function(i) input[[i]], USE.NAMES = FALSE),
                              Date_heure= Sys.time() )
      responses <-  responses %>% dplyr::filter (responses$Traitement=="TRUE")
      
      # if file doesn't exist in current wd, col.names = TRUE + append = FALSE
      # if file does exist in current wd, col.names = FALSE + append = TRUE
      if(!file.exists("data/traitement.csv")) {
        fwrite(responses, "data/traitement.csv", 
                    col.names = TRUE, 
                    row.names = FALSE,
                    append = FALSE,
                    sep = ";")
      } else {
        fwrite(responses, "data/traitement.csv", 
                    col.names = FALSE, 
                    row.names = FALSE,
                    append = TRUE, 
                    sep = ";")
      }
      # tell user form was successfully submitted
      showModal(modalDialog("Successfully submitted",
                            easyClose = TRUE,
                            footer = NULL,
                            class = "success")) 
      # reset all checkboxes and username
      sapply(rvs$data$Nom, function(x) updateCheckboxInput(session, x, value = FALSE))
      updateTextInput(session, "username", value = "")
    }
  })
 
  

  #output$tableassurance <- renderImage(filename<-"page_en_cons.png",deleteFile=FALSE)
  #output$tableepargne <- renderImage(filename<-"page_en_cons.png",deleteFile=FALSE)
  

  output$timelineWC <- timevis::renderTimevis({
    timevis(dataWC2)
  })
  



})




#shinyApp(ui, server) downloadEparData
#runApp(host = "10.70.126.1", port = 8080)

