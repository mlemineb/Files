

############################ APPLICATION SHINY ############################ 
library(shinyjs)
library(shinysky)
library(shinyalert)
library(particlesjs)
useShinyalert()

#------------UI ---------#

#Dashboard header carrying the title of the dashboard
header <- dashboardHeader(
  title = span(img(src = "radar.svg", height = 35), "WEB-TRACK"),
  titleWidth = 300,
  dropdownMenu(
    type = "notifications", 
    headerText = strong("HELP"), 
    icon = icon("question"), 
    badgeStatus = NULL,
    notificationItem(
      text = (steps$text[1]),
      icon = icon("home")
    ),
    notificationItem(
      text = steps$text[2],
      icon = icon("dashboard")
    ),
    notificationItem(
      text = steps$text[3],
      icon = icon("landmark")
    ),
    notificationItem(
      text = steps$text[4],
      icon = icon("car-crash")
    ),
    notificationItem(
      text = steps$text[5],
      icon = icon("piggy-bank")
    )
  ),
  tags$li(
    a(
      strong("A PROPOS "),
      height = 40,
      href = "https://github.com/ceefluz/radar/blob/master/README.md",
      title = "",
      target = "_blank"
    ),
    class = "dropdown"
  )
)


#Sidebar content of the dashboard
sidebar <- dashboardSidebar( width = 300,
  sidebarMenu(
    HTML(paste0(
      "<br>",
      "<a href='https://www.nps.gov/index.htm' target='_blank'><img style = 'display: block; margin-left: auto; margin-right: auto;' src='unnamed.png' width = '186'></a>",
      "<br>",
      "<br>"
    )),
    menuItem("Accueil", tabName = "home", icon = icon("home")),
    menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
    menuItem("Stat Agent", tabName = "charts", icon = icon("stats", lib = "glyphicon")),
    menuItem(tabName = "extra", "Crédit Conso", icon = icon("landmark")),
    menuItem(tabName = "extra1", "Assurance", icon = icon("car-crash")),
    menuItem(tabName = "extra2", "Epargne", icon = icon("piggy-bank")),
    menuItem(tabName = "extra3", "Evolution",icon=icon("calendar")),
    
    HTML(paste0(
      "<br><br><br><br><br><br><br><br><br>",
      "<table style='margin-left:auto; margin-right:auto;'>",
      "<tr>",
      "<td style='padding: 5px;'><a href='https://www.linkedin.com/in/mohamed-lemine-beydia' target='_blank'><i class='fab fa-linkedin fa-lg' style='color:white'></i></a></td>",
      "<td style='padding: 5px;'><a href='https://twitter.com/m_lemine_b' target='_blank'><i class='fab fa-twitter fa-lg' style='color:white'></i></a></td>",
      "</tr>",
      "</table>",
      "<br>"),
    
    HTML(paste0(
      "<script>",
      "var today = new Date();",
      "var yyyy = today.getFullYear();",
      "</script>",
      "<p style = 'text-align: center; color: white'><small>&copy; - <a style='color:white' href='mohamed.beydia@ca-sudmed.fr' target='_blank'>CA Sudmed - Mohamed Beydia</a> - <script>document.write(yyyy);</script></small></p>")
    )
  )
)
)


frow1 <- fluidRow(
  valueBoxOutput("value1")
  ,valueBoxOutput("value2")
  ,valueBoxOutput("value3")
  ,valueBoxOutput("value4")
  ,valueBoxOutput("value5")
  ,valueBoxOutput("value6")
)








# combine the two fluid rows to make the body
body <- dashboardBody(
  #tags$head(
  #tags$link(
   # rel = "stylesheet", 
   # type = "text/css", 
   # href = "radar_style.css")
#),
  
  tags$head(tags$style(HTML('
        /* logo */
        .skin-blue .main-header .logo {
                              background-color: #106B50;
                              }

        /* logo when hovered */
        .skin-blue .main-header .logo:hover {
                              background-color: #106B50;
                              }

        /* navbar (rest of the header) */
        .skin-blue .main-header .navbar {
                              background-color: #106B50;
                              }        

        /* main sidebar */
        .skin-blue .main-sidebar {
                              background-color: #106B50;
                              }

        /* active selected tab in the sidebarmenu */
        .skin-blue .main-sidebar .sidebar .sidebar-menu .active a{
                              background-color: #E21A3B;
                              }

        /* other links in the sidebarmenu */
        .skin-blue .main-sidebar .sidebar .sidebar-menu a{
                              background-color: none;
                              color: #000000;
                              }

        /* other links in the sidebarmenu when hovered */
         .skin-blue .main-sidebar .sidebar .sidebar-menu a:hover{
                              background-color: none ;
                              }
        /* toggle button when hovered  */                    
         .skin-blue .main-header .navbar .sidebar-toggle:hover{
                              background-color: none;
         }
       .skin-blue .main-sidebar .sidebar .sidebar-menu  li  a,
       .skin-blue .main-sidebar .sidebar .sidebar-menu > li:hover  a {
       color: #ffffff;
}
                              '))),

useShinyjs(),
introjsUI(),

tabItems(
  tabItem(tabName = "home",  tags$head(tags$style("
    .particles-full {
      z-index: 1;
    }
    .box {
      z-index: 2;
    }
  ")),
          particles('custom_particles.json'),
          includeHTML("intro_real.html"),
		  #ajout d'un appel à un script javascript
		  includeScript("www/js/remove_particles.js")
		  ),
  tabItem(tabName = "dashboard",frow1,
          fluidRow(
            
            box(
              title = "Evolution des simuations conso non-abouties et Accords Web-tracking"
              ,status = "primary"
              ,solidHeader = TRUE 
              ,collapsible = TRUE 
              ,plotOutput("contact_webtrack", height = "300px") %>% withSpinner(color = "green") 
            ) 
            
            ,box(
              title = "Evolution des Accords Web-tracking"
              ,status = "primary"
              ,solidHeader = TRUE 
              ,collapsible = TRUE 
              ,plotOutput("accord_webtrack", height = "300px") %>% withSpinner(color = "green") 
            ) 
            
          )),
  tabItem(tabName = "charts",
    fluidRow( column(4,
             selectInput("man",
                         "Matricule:",
                         c("Tous",
                           unique(as.character(STAT$ID_AGT))))
     ) ,
     column(4,   selectInput("trans",
                         "Nom:",
                         c("Tous",
                           unique(as.character(STAT$NOM_AGT))))
     ) ,
      
    DT::dataTableOutput("StatNPC")%>% withSpinner(color = "green")),
    
    fluidRow(
      
      box(
        title = "Nombre de RAC accord par agent"
        ,status = "primary"
        ,solidHeader = TRUE 
        ,collapsible = TRUE 
        ,plotOutput("accordbyAgent", height = "300px") %>% withSpinner(color = "green") 
      ) 
      
      ,box(
        title = "Taux de succés par agent"
        ,status = "primary"
        ,solidHeader = TRUE 
        ,collapsible = TRUE 
        ,plotOutput("succesparAgent", height = "300px") %>% withSpinner(color = "green") 
      ) 
      
    ) ),
  
  tabItem(tabName = "extra",
          fluidPage(
            mainPanel(
              tabsetPanel(
                tabPanel("A Traiter",
                         # style modals
                         tags$style(
                           HTML(
                             ".error {
                    background-color: red;
                    color: white;
                    }
                    .success {
                    background-color: green;
                    color: white;
                    }"
                           )),
                         h2("Liste des simulations Conso non aboutis (alimentation toutes les 15 minutes)"),
                         p("Pour traiter un lead, cochez la case en derniere colone et saisissez votre Matricule Agent en bas"),
                         DT::dataTableOutput('checkbox_table',width = "1200px"),
                         br(),
                         textInput(inputId = "username", label= "Saisissez votre Matricule Agent (L50)"),
                         actionButton(inputId = "submit", label= "Validez")
                ),
                tabPanel("Deja traite", DT::dataTableOutput("mytable2"))
              )
            ))
  ),
  
  
  
  tabItem(tabName = "extra1",fluidPage(img(src = 'page_en_cons.png'))),
  tabItem(tabName = "extra2",fluidPage(img(src = 'page_en_cons.png'))),
  tabItem(tabName = "extra3",fluidPage(titlePanel("Evolution du projet Webtracking au fil du temps ")
,
    timevisOutput("timelineWC")))
  
),

)


#completing the ui part with dashboardPage
ui <- shinydashboard::dashboardPage( skin = "blue",title = 'Application de Web Tracking by CA-Sudmed', 
                                     header, sidebar, body)


# Wrap your UI with secure_app
ui <- secure_app(ui,language = "fr")

