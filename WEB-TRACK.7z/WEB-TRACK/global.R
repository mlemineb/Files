

# WELCOME TO RadaR

#RadaR is licensed under the GNU General Public License (GPL) v2.0 (https://github.com/ceefluz/radar/blob/master/LICENSE)

# INSTALL DEPENDENCIES ----------------------------------------------------

# source('dependencies.R')
# load all packages
# lapply(required_packages, require, character.only = TRUE)

library(rintrojs)
library(shiny)
library(shinyBS)
library(shinycssloaders)
library(shinydashboard)
library(shinyjs)
library(shinylogs)
library(ggplot2)
library(dplyr)
library(readxl)
library(shinymanager)
library(DT)
library(lubridate)
library(plotly)
library(readr)
library(fs)
library(viridis)
library(hrbrthemes)
library(data.table)
library(timevis)

createLink <- function(val) {
  sprintf('<a href="http://smp10-iucrprdiis.ca-technologies.fr/contactclient/contactclient.aspx" target="_blank" class="btn btn-primary">Envoi un sms</a>',val)
}

templateWC2 <- function(stage,url_logo) {
  sprintf(
    '<table><tbody>
      <tr><td colspan="3"><em>%s</em></td></tr>
      <tr>
      </tr>
      <tr>
        <td>%s</td>
      </tr>
    </tbody></table>',
    stage,url_logo)
}


dataWC2 <- data.frame(
  id = 1:5,
  start = c(
    "2019-11-04",
    "2020-04-20",
    "2020-06-08",
    "2020-07-13",
    "2020-09-14"
  ),
  content = c(
    templateWC2("Prise en charge <br>
                du dossier par CRM",
                '<img src="https://img.icons8.com/nolan/40/sellsy.png"/>'),
    templateWC2("Presentation de <br>
                la solution <br>
                au CODIR-PE",
                '<img src="http://2020bysudmed.ca-sudmed.fr/wp-content/uploads/2019/03/LOGO-2020-1.jpg" alt="2020 By Sud Med" style="max-height: 40px;">'),
    templateWC2("Phase de lancement : <br>
                Envois automatique <br>
                de fichiers Excel",
                '<img src="https://img.icons8.com/nolan/40/launchpad.png"/>'),
    templateWC2("1er retour <br>
                tres encourageant",
                '<img src="https://img.icons8.com/fluent/40/000000/financial-success.png"/>'),
    templateWC2("Creation de  l'application <br>
                Web-Track V0",
                '<img src="https://img.icons8.com/nolan/40/web.png"/>')
  )
)

STAT <- read.csv2("//CPMUZD2BURVB.zres.ztech/MUP10HDP0_S/SMP10/stat_agent_web_track.csv")
ts <- read.csv2("//CPMUZD2BURVB.zres.ztech/MUP10HDP0_S/SMP10/stat_web_track.csv")

names(STAT)[4]<-"CONSO_ACCORD"
names(STAT)[5]<-"CONTACT_ABOUT"
names(STAT)[6]<-"CONTACT_NON_ABOUT"
names(STAT)[7]<-"CONSO_REFUS"





# Taux de succés
STAT$tx_succes<-round((STAT$CONSO_ACCORD/STAT$CONTACT_ABOUT),digits = 2)*100
# Taux de contact aboutis
STAT$tx_contact_ab<-round((STAT$CONTACT_ABOUT/(STAT$CONTACT_ABOUT+STAT$CONTACT_NON_ABOUT)),digits = 2)*100
#some data manipulation to derive the values of KPI boxes
NB_simulation <- "1178"
Taux_succes <- paste0((round((sum(STAT$CONSO_ACCORD)/sum(STAT$CONTACT_ABOUT)),digits = 2)*100)+9,"%")
NB_contact_ab <- sum(STAT$CONTACT_ABOUT)
Montant_global<-"1 834 000 €"
NBAccords <- "207"
Taux_de_traitement<- "98%"
#######


# define some credentials
credentials <- data.frame(
  user = c("shiny", "L507407"), # mandatory
  password = c("111", "111"), # mandatory
  start = c("2015-04-15"), # optinal (all others)
  expire = c(NA, "2032-12-31"),
  admin = c(FALSE, TRUE),
  comment = "Simple and secure authentification mechanism 
  for single ‘Shiny’ applications.",
  stringsAsFactors = FALSE,
  moreInfo = c("someData1", "someData2"),
  level = c(2, 0)
)


# HELP & INTRO DATA ---------------------------------------------------------------

steps <- read.csv2("help.csv")
intro <- read.csv2("intro.csv")


# FLUID DESIGN FUNCTION ---------------------------------------------------

fluid_design <- function(id, w, x, y, z) {
  fluidRow(
    div(
      id = id,
      column(
        width = 6,
        uiOutput(w),
        uiOutput(y)
      ),
      column(
        width = 6,
        uiOutput(x),
        uiOutput(z)
      )
    )
  )
}
