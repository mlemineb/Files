library(shinymanager)
runApp("C:/Users/L507407/Desktop/SHINY_APP_2", host="0.0.0.0", port=1234)




library(data.table)
library(tidyverse)
library(readxl)
setwd("C:/Users/L507407/Desktop/web")
tbl_fread <- 
  list.files(pattern = "*.xlsx",) %>% 
  map_df(~fread(fill=TRUE))


### *data.table* / *purrr* hybrid
map_df_read_excel <- function(path, pattern = "*.xlsx") {
  list.files(path, pattern, full.names = TRUE) %>% 
    map_df(~read_excel(.))
}


map_df_read_excel = map_df_read_excel("C:/Users/L507407/Desktop/web/")
 library(dplyr)

saveRDS(map_df_read_excel,"map_df_read_excel.RDS")

df<-map_df_read_excel[,c(1,2,5)]

df2 <- df %>% group_by(ID_PART,`Nom Produit`) %>% summarise(Value = max(`date simulation`))
library(lubridate)
# parese date
df2$date <- ymd_hms(as.character(df2$Value))

# get hours
df2$heure<-hour(df2$date)
# get minutes
df2$minute<-minute(df2$date)
# get minutes
df2$second<-second(df2$date)
# get hours+minutes
df2$time<-hms(paste(df2$heure,df2$minute,df2$second,sep=":"))
# weekdays
df2$weekdays<-factor(weekdays(df2$date),levels=c("dimanche","lundi","mardi","mercredi","jeudi","vendredi"))

df2$month<-factor(months(df2$date),levels=c("juillet","août","septembre"))


#nb
df2$nb<-1



plot1_df <- df2 %>% group_by(weekdays) %>% summarise(Value = sum(nb))
plot1_df2 <- df2 %>% group_by(month) %>% summarise(Value = sum(nb))
plot1_df3 <- df2 %>% group_by(heure) %>% summarise(Value = sum(nb))

plot1_df2<-plot1_df
plot1_df2[1,]<-plot1_df[1,]
plot1_df2[2,]<-plot1_df[3,]
plot1_df2[3,]<-plot1_df[4,]
plot1_df2[4,]<-plot1_df[5,]
plot1_df2[5,]<-plot1_df[2,]
plot1_df2[6,]<-plot1_df[6,]

xform <- list(categoryorder = "array",
              categoryarray = c("giraffes", 
                                "orangutans", 
                                "monkeys"))

library(plotly)
plot_ly(plot1_df2, x = ~weekdays,y = ~Value,type = "bar") 

plot_ly(plot1_df3,name = "Nombre de simulations non aboutis par Heure") %>%
  add_trace(y=~Value, x=~heure, type='scatter', mode='lines+markers')



qicharts2::qic(heure, Value,
    data = plot1_df3, 
    agg.fun = "sum",
    decimals = 2,
    xlab = "Year",
    ylab = "Count",
    title = "Admissions per year") 