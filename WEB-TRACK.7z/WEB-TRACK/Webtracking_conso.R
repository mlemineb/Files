############################################################## SCRIPT DE 10H du matin ######################################################


###### ACESING THE DATA FROM THE WEB############


#install.packages('RCurl')

library(RCurl)
library(dplyr)
library(jsonlite)

URL_1_today <- "https://apirest.atinternet-solutions.com/data/v2/json/getData?&columns=%7Bd_visit_id,cl_470430,cl_470424,d_visitor_text_id,d_cusvar9,cl_470422,d_cusvar29,cl_470427,cl_470421,m_visits,m_time_spent_per_pages_visits,d_cusvar3,d_cusvar12,d_cusvar24,d_date_hour_event,d_time_spent_per_visit%7D&sort=%7B-m_visits%7D&filter=%7B$OR:%7Bd_visitor_text_id:%7B$lk:'871'%7D,d_visitor_text_id:%7B$empty:false%7D%7D,d_cusvar3:%7B$nlk:'N/A'%7D%7D&space=%7Bs:599235%7D&period=%7BR:%7BD:'0'%7D%7D&max-results=50&page-num=1&apikey=1b9017ae-1fb3-4c4f-907d-138a5a10ce3f"

URL_2_today <-"https://apirest.atinternet-solutions.com/data/v2/json/getData?&columns=%7Bd_visit_id,cl_470422,d_cusvar9,m_visits%7D&sort=%7B-m_visits%7D&filter=%7Bcl_470422:%7B$lk:'CACF'%7D,$OR:%7Bd_cusvar9:%7B$lk:'formulaire%20de%20rappel%20d%C3%A9connect%C3%A9_info%20valid%C3%A9'%7D,d_cusvar9:%7B$lk:'reponse%20d%C3%A9connect%C3%A9'%7D%7D%7D&space=%7Bs:599235%7D&period=%7BR:%7BD:'0'%7D%7D&max-results=50&page-num=1&apikey=1b9017ae-1fb3-4c4f-907d-138a5a10ce3f"


# Seting 
library(httr)

proxy_config <- config(
  proxy = curl::ie_get_proxy_for_url(),
  proxyauth = 8,
  proxyuserpwd = ":",
  ssl_verifypeer = 0
)
curl <- getCurlHandle()
curlSetOpt(.opts = list(proxy = proxy_config$options$proxy), curl = curl)

# retriving data from the web
file1_today <- getURL(URL_1_today, curl = curl)
file2_today <- getURL(URL_2_today, curl = curl)


# Import JSON file to data frames
datafomJson_1_today<-fromJSON(file1_today) %>% as.data.frame
datafomJson_2_today<-fromJSON(file2_today) %>% as.data.frame



dataset_query1_today<-datafomJson_1_today$DataFeed.Rows[[1]]
dataset_query2_today<-datafomJson_2_today$DataFeed.Rows[[1]]


################### DATA PRE-PROCESSING ###########################



DATASET_1<-data.frame(dataset_query1_today)
DATASET_2<-data.frame(dataset_query2_today)


DATASET_3<- DATASET_1 %>% filter(!d_visit_id %in% DATASET_2$d_visit_id )




###########################################"

# import csv from sas

library(readr)
DATASET_4 <- read_delim("S:/MKG_OPERATIONNEL/MARKETING/MOHAMED/PE/sas_webtracking/DATASET_4.csv", 
                        ";", escape_double = FALSE, trim_ws = TRUE)

#1.rename vars
#install.packages("data.table")
library(data.table)
setnames(DATASET_3, "cl_470430", "Nom Produit")
setnames(DATASET_3, "d_cusvar12", "Duree du pr�t")
setnames(DATASET_3, "d_cusvar3", "Montant_Projet")
setnames(DATASET_3, "d_time_spent_per_visit", "Temps pass� par visite")
setnames(DATASET_3, "d_date_hour_event", "date simulation")
setnames(DATASET_3, "d_visitor_text_id", "ID_PART")

#2 cleaning  "ID_PART"
#install.packages("stringr")
library(stringr)
DATASET_3$ID_PART<-str_replace(DATASET_3$ID_PART, pattern="87100-" ,replacement="")

#3 delete lines when id=0
DATASET_3 <-DATASET_3[DATASET_3$ID_PART != 0,]

#4 count distinct id_part

library(dplyr)
Nb_de_Simul<-(DATASET_3 %>%
                group_by(ID_PART) %>%
                summarise(Nb_de_Simul = n()))

#5 join of dataset_3 and nb_de_simul 
DATASET_5 <- left_join(DATASET_3,Nb_de_Simul,by='ID_PART')

#6 join of dataset_5 and dataset_4 
DATASET_6 <- left_join(DATASET_5,DATASET_4,by='ID_PART')
DATASET_6$ID_PART <-as.character(DATASET_6$ID_PART)

DATASET_6<- DATASET_6 %>% filter(ID_PART %in% DATASET_4$ID_PART )

DATASET_6<-DATASET_6 %>% group_by(ID_PART) %>% top_n(1, `date simulation`)


DATASET_6<-DATASET_6[,-c(3,5,6,7,8,9,10,14)]

names(DATASET_6)[12]<-"NOTE BALE 2"
names(DATASET_6)[13]<- "AGE"


DATASET_6<-DATASET_6[,c(2,3,11,16,7,9,5:6,12:15,18,4,21,22)]
names(DATASET_6)[12]<- "NU_COMPTE"
names(DATASET_6)[11]<- "PDV"


DATASET_6$HEURE_SIMULATION<-gsub(".*T","",DATASET_6$`date simulation`)
DATASET_6$DATE_SIMULATION<-gsub("T.*","",DATASET_6$`date simulation`)
DATASET_6$DATE_SIMULATIONS <- as.POSIXct(paste(DATASET_6$DATE_SIMULATION,DATASET_6$HEURE_SIMULATION))

compare_date<-as.POSIXct(paste(Sys.Date()-1,"14:55:00"))

DATASET_7<-filter(DATASET_6, AGE <=65,`NOTE BALE 2` %in% c('A','B','C','D','E','F','G','H',NA))


DATASET_7<-DATASET_7[-c(5,2,11,13,14,17,18)]
DATASET_7<-DATASET_7[c(9,2,1,12,4:6,8,7,10,11,3)]


DATASET_8<-DATASET_7 %>% arrange(desc(DATASET_7$DATE_SIMULATIONS,DATASET_7$NU_COMPTE))

DATASET_8$TRAIT_PAR<-""

createLink <- function(val) {
  sprintf('<a href="http://smp10-iucrprdiis.ca-technologies.fr/contactclient/contactclient.aspx" target="_blank" class="btn btn-primary">Envoi un sms</a>',val)
}

DATASET_8<-cbind.data.frame(DATASET_8,data.frame(Envoyer_sms=createLink(DATASET_8$NOMPART)))

############################# Exportation file webtracking ############################# 
library("xlsx")


write.xlsx(DATASET_8, file ="data/Webtracking.xlsx")




